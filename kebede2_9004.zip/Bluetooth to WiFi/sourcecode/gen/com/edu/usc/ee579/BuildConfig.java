/** Automatically generated file. DO NOT MODIFY */
package com.edu.usc.ee579;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
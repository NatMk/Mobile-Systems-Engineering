
An Introduction to Bluetooth

This program implements two-way text chat over Bluetooth between two Android devices, using all the fundamental Bluetooth API capabilities.
The program should be run on two Android devices at the same time, to establish a two-way chat over Bluetooth between the devices. 
Select "Made discoverable" in overflow menu on one device and click on the Bluetooth icon on the other one, to find the device and establish the connection.

The program supports the following, using the Bluetooth API:

Setting up Bluetooth
Broadcasting a devices availability to nearby devices. 
Scanning for other Bluetooth available BT/BLE devices
Establishing a connection to a remote device
Exchanging strings/data between devices over Bluetooth
Allowing devices to act both as client and server, without predesignating which one to be server and receiver.

Pre-requisites
Android SDK 27
Android Build Tools v27.0.2
Android Support Repository

Getting Started
This program uses the Gradle build system. To build this project, use the "gradlew build" command or use "Import Project" in Android Studio.
Once the project is imported, the project can be built and run using the build button and loaded onto a device plugged into. 
Once the devices have the application loaded onto them. Both can be run and paired in order to arbitrarily send strings to one another via the bluetooth protocol.

Support
Google+ Community: https://plus.google.com/communities/105153134372062985968
Stack Overflow: http://stackoverflow.com/questions/tagged/android
Googlesamples Github: https://github.com/googlesamples/android-BluetoothChat

License
Copyright 2017 The Android Open Source Project, Inc.
Licensed to the Apache Software Foundation (ASF) under one or more contributor license agreements. 
The ASF licenses is under the Apache License, Version 2.0 (the "License")
http://www.apache.org/licenses/LICENSE-2.0

